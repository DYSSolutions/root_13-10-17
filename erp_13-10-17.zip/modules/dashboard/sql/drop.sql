DROP TABLE IF EXISTS `0_dashboard_widgets`;
DROP TABLE IF EXISTS `0_dashboard_reminders`;
